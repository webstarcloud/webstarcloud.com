"""Fetch only owner-configured public pages, respect robots, publish an atomic snapshot."""

import argparse
import hashlib
import ipaddress
import json
import socket
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import httpx
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
AGENT = "GobwenIndex/1.0 (+https://davidwebstar.com/research)"


def public_url(url: str, hosts: set[str]) -> None:
    parsed = urlparse(url)
    if (
        parsed.scheme != "https"
        or parsed.hostname not in hosts
        or parsed.port not in {None, 443}
        or parsed.username
        or parsed.password
    ):
        raise ValueError("Only configured public HTTPS hosts can be indexed")
    addresses = socket.getaddrinfo(parsed.hostname, 443, type=socket.SOCK_STREAM)
    if not addresses or any(
        not ipaddress.ip_address(item[4][0]).is_global for item in addresses
    ):
        raise ValueError("Private or reserved network destination rejected")


def fetch(
    client: httpx.Client,
    url: str,
    hosts: set[str],
    allowed: Callable[[str], bool] | None = None,
) -> tuple[str, str]:
    deadline = time.monotonic() + 15
    for _ in range(4):
        public_url(url, hosts)
        if allowed is not None and not allowed(url):
            raise ValueError(f"Robots disallows configured page: {url}")
        with client.stream("GET", url, follow_redirects=False, timeout=5) as response:
            if response.status_code in {301, 302, 303, 307, 308}:
                url = urljoin(url, response.headers["location"])
                continue
            if response.status_code == 404 and urlparse(url).path == "/robots.txt":
                return url, ""
            response.raise_for_status()
            if not any(
                kind in response.headers.get("content-type", "")
                for kind in ("text/html", "text/plain", "application/xhtml+xml")
            ):
                raise ValueError("Only HTML or plain text can be indexed")
            raw = bytearray()
            for chunk in response.iter_bytes():
                raw.extend(chunk)
                if len(raw) > 1_000_000 or time.monotonic() > deadline:
                    raise ValueError("Page exceeded size or time limit")
            return url, raw.decode("utf-8", errors="replace")
    raise ValueError("Too many redirects")


def extract(html: str, content_selector: str | None = None) -> tuple[str, list[str]]:
    soup = BeautifulSoup(html, "html.parser")
    title = (
        soup.title.get_text(" ", strip=True)[:120] if soup.title else "Untitled source"
    )
    for node in soup.select("script,style,nav,header,footer,aside,form,noscript"):
        node.decompose()
    if content_selector is not None:
        main = soup.select_one(content_selector)
        if main is None:
            raise ValueError("Configured content selector did not match the page")
    else:
        main = soup.find("article") or soup.find("main") or soup.body or soup
    text = " ".join(main.get_text(" ", strip=True).split())[:100_000]
    # Overlapping, bounded excerpts preserve enough adjacent context for retrieval.
    words = text.split()
    passages = [
        " ".join(words[start : start + 65]) for start in range(0, len(words), 45)
    ]
    return title, [p for p in passages if len(p) >= 40]


def build(config: Path, output: Path) -> dict:
    spec = json.loads(config.read_text())
    entries = spec["sources"]
    if not 1 <= len(entries) <= 50 or not 1 <= spec["max_age_days"] <= 30:
        raise ValueError("Configure 1..50 pages with 1..30 days maximum age")
    hosts = {urlparse(entry["url"]).hostname for entry in entries}
    robots, documents = {}, []
    with httpx.Client(headers={"User-Agent": AGENT}, trust_env=False) as client:

        def allowed(url: str) -> bool:
            origin = f"https://{urlparse(url).netloc}"
            if origin not in robots:
                _, rules = fetch(client, origin + "/robots.txt", hosts)
                parser = RobotFileParser()
                parser.parse(rules.splitlines())
                robots[origin] = parser
            return robots[origin].can_fetch(AGENT, url)

        for entry in entries:
            url = entry["url"]
            final_url, page = fetch(client, url, hosts, allowed)
            title, passages = extract(page, entry.get("content_selector"))
            if not passages:
                raise ValueError(f"No readable content found: {url}")
            documents.append(
                {
                    "url": final_url,
                    "title": title,
                    "keywords": entry.get("keywords", []),
                    "text": " ".join(passages),
                    "passages": passages,
                    "sha256": hashlib.sha256(page.encode()).hexdigest(),
                }
            )
            print(
                json.dumps({"indexed": final_url, "passages": len(passages)}),
                flush=True,
            )
    result = {
        "schema": 1,
        "indexed_at": datetime.now(UTC).isoformat(),
        "max_age_days": spec["max_age_days"],
        "documents": documents,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(".tmp")
    temporary.write_text(json.dumps(result, ensure_ascii=True))
    temporary.replace(output)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "search/sources.json")
    parser.add_argument(
        "--output", type=Path, default=ROOT / ".build/trusted-index.json"
    )
    args = parser.parse_args()
    build(args.config, args.output)
