"""Conservative lexical source boundaries. Passing is not factual verification."""

import re
from datetime import UTC, datetime

STOP = {
    "a",
    "an",
    "the",
    "to",
    "of",
    "is",
    "are",
    "was",
    "were",
    "who",
    "what",
    "when",
    "where",
    "how",
    "do",
    "does",
    "did",
    "have",
    "has",
    "had",
    "many",
    "much",
    "some",
    "any",
    "all",
    "be",
    "been",
    "being",
    "their",
    "there",
    "that",
    "this",
    "these",
    "those",
    "why",
    "which",
    "can",
    "i",
    "you",
    "it",
    "its",
    "on",
    "in",
    "at",
    "for",
    "and",
    "or",
    "with",
    "from",
    "my",
    "please",
    "tell",
    "me",
    "about",
    "explain",
    "search",
    "look",
    "up",
    "current",
    "latest",
    "today",
    "official",
    "release",
    "date",
}
ALIASES = {
    "dutch": "netherlands",
    "installation": "install",
    "installed": "install",
    "installing": "install",
}


def terms(text: str) -> set[str]:
    return {
        ALIASES.get(t, t)
        for t in re.findall(r"[a-z0-9]{2,}", text.lower())
        if t not in STOP
    }


def valid_index_date(
    value: str | None, now: datetime | None = None, max_age_days: float = 7
) -> bool:
    """Index age is a snapshot bound, never a publication/factual freshness claim."""
    if not isinstance(value, str):
        return False
    try:
        created = datetime.fromisoformat(value)
        current = now or datetime.now(UTC)
        if (
            created.tzinfo is None
            or current.tzinfo is None
            or not 0 < max_age_days <= 7
        ):
            return False
        return 0 <= (current - created).total_seconds() <= max_age_days * 86400
    except (TypeError, ValueError, OverflowError):
        return False


def qualified_excerpt(query: str, title: str, excerpt: str) -> bool:
    """Require lexical subject coverage and reject obvious teasers/promotion.

    These checks can reject useful paraphrases and accept incorrect assertions.
    They are admission bounds, not confidence or entailment scores.
    """
    wanted = terms(query)
    body = terms(excerpt)
    matched = wanted & (terms(title) | body)
    if not wanted or not wanted & body:
        return False  # A matching title plus unrelated prose is insufficient.
    if len(matched) < min(2, len(wanted)) or len(matched) / len(wanted) < 0.5:
        return False
    if re.search(
        r"\b(?:buy now|shop now|sign up|subscribe now|limited.time offer|"
        r"industry.leading|world.?s best|try.{0,20}for free)\b",
        excerpt,
        re.IGNORECASE,
    ):
        return False
    if re.fullmatch(
        r"\s*(?:read more|learn more|click here)[.!\s]*", excerpt, re.IGNORECASE
    ):
        return False
    # A news appearance is not an identity answer, despite repeated royal names.
    news_only = (
        re.match(r"\s*who (?:is|are)\b", query, re.IGNORECASE)
        and re.search(
            r"\b(?:attend|attends|attending|visit|visits|funeral|conference)\b",
            excerpt,
            re.IGNORECASE,
        )
        and not re.search(
            r"\b(?:is|are|became|succeeded|reigns|serves)\b", excerpt, re.IGNORECASE
        )
    )
    return not news_only


def needs_comparison_clarification(query: str) -> bool:
    if not re.match(r"\s*(?:who|which|what)\b", query, re.IGNORECASE) or not re.search(
        r"\b(?:winning|winner|best|better|leading|ahead|strongest)\b",
        query,
        re.IGNORECASE,
    ):
        return False
    # Concrete metrics/dates and sporting contests remain factual retrieval.
    # Open 'AI race' and 'best model' claims need a criterion before ranking.
    scoped = re.search(
        r"\b(?:swe.bench|mmlu|aime|gpqa|livecodebench|terminal.bench|hle|osworld|"
        r"benchmark|leaderboard|revenue|market share|latency|cost|price|accuracy|"
        r"tokens per second|score|match|game|cup|league|race result|today|yesterday|"
        r"current|currently|latest|20\d{2})\b",
        query,
        re.IGNORECASE,
    )
    return not scoped
