"""Small, immutable trusted-page index. No network or model is used for retrieval."""

import math
from collections import Counter
from datetime import UTC, datetime

from source_quality import qualified_excerpt, terms, valid_index_date


def web_results(query: str, items: list) -> list[dict]:
    """Drop obviously unrelated snippets before giving the model any candidates."""
    results = []
    for item in items[:24]:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title", ""))[:120]
        excerpt = str(item.get("content", ""))[:500]
        if not qualified_excerpt(query, title, excerpt):
            continue
        results.append(
            {
                "title": title,
                "url": str(item.get("url", ""))[:1500],
                "excerpt": excerpt,
                "kind": "web",
            }
        )
        if len(results) == 8:
            break
    return results


def retrieve(query: str, index: dict, now: datetime | None = None) -> list[dict]:
    now = now or datetime.now(UTC)
    if not valid_index_date(index.get("indexed_at"), now, index.get("max_age_days", 7)):
        return []  # Stale snapshots must not silently answer current questions.
    wanted = terms(query)
    if not wanted:
        return []
    documents = index["documents"]
    tokens = [
        terms(doc["title"] + " " + doc["text"] + " " + " ".join(doc["keywords"]))
        for doc in documents
    ]
    frequency = Counter(term for doc in tokens for term in doc)
    scored = []
    for doc, available in zip(documents, tokens, strict=True):
        # A body-only keyword overlap is not enough to establish the subject of
        # a curated page. Otherwise generic prose can outrank the web fallback.
        subject = terms(doc["title"] + " " + " ".join(doc["keywords"]))
        if not wanted & subject:
            continue
        matched = wanted & available
        if len(matched) < min(2, len(wanted)) or len(matched) / len(wanted) < 0.5:
            continue
        # Rare query terms matter more than generic words shared by many pages.
        score = sum(math.log(1 + len(documents) / frequency[t]) for t in matched)
        passages = doc["passages"]
        # The title already establishes the subject. Rank remaining details;
        # broad identity queries prefer the lead instead of repeated news names.
        details = wanted - terms(doc["title"])
        qualified = [p for p in passages if qualified_excerpt(query, doc["title"], p)]
        if not qualified:
            continue
        best = max(qualified, key=lambda p: len(details & terms(p)))
        scored.append(
            (
                score,
                {
                    "title": doc["title"],
                    "url": doc["url"],
                    "excerpt": best[:500],
                    "kind": "indexed",
                    "indexedAt": index["indexed_at"],
                },
            )
        )
    scored.sort(key=lambda item: item[0], reverse=True)
    return [source for _, source in scored[:3]]
