# Gobwen private search

Two lookup paths run in a separate 512 MB ARM64 Lambda, concurrency two, maximum
20 seconds per invocation. There is no public URL, always-on server or paid search
API. Normal AWS invocation, compute, image storage and log charges still apply.

1. `sources.json` lists exact trusted HTTPS pages and optional retrieval keywords.
   Optional `content_selector` restricts extraction to a specific page section;
   a missing selector fails the refresh rather than silently indexing the whole
   page. The Royal House entry selects its introduction to exclude the news feed.
   The build-time indexer obeys robots rules, rejects private destinations, follows
   only configured hosts, caps downloads and extracts readable text. It never
   crawls links automatically. The first snapshot covers five pages: Omarchy's
   manual and installation guide, the Dutch Royal House, Qwen's quickstart and
   Python's tutorial. Keyword ranking selects bounded excerpts, not generated facts.
2. `settings.yml` configures the whole-web engine list. Initially Google, Bing and
   DuckDuckGo are enabled through SearXNG. Missing/expired/insufficient indexed
   matches fall back to those engines. No paid API key, proxy rotation or CAPTCHA
   bypass is used. Engines may block or change their pages; empty retrieval is
   surfaced honestly. A basic term-overlap filter removes obviously unrelated
   results; it is not a semantic relevance guarantee. Search-engine snippets are
   not full-page verification.

Only the current question is passed to the search function, never chat history,
identity or auth tokens. For indexed hits the question stays in AWS. A web fallback
sends it to the configured upstream engines. Search/HTTP libraries' logs are
suppressed because they can contain query URLs; the facade logs only counts,
route, engine failure names and elapsed time. Conversation capture still follows
the chat's separate opt-in setting.

The model worker validates HTTPS sources, strips markup and runs the input hardener.
A single source is displayed directly without loading the model; multiple sources
limit the model to selecting source IDs. User text cannot choose a function,
engine or URL to fetch. The public gateway quotas apply before this function;
one atomic counter additionally caps lookup attempts at 1,000 per UTC month.
Database failure stops lookup. SearXNG's public-instance limiter is disabled
because the function is private and IAM-controlled, not an open search proxy.

## Change the lists and refresh

From the `model-lambda` directory:

```sh
uv sync --frozen
# Edit search/sources.json and/or search/settings.yml.
uv run python scripts/index_sources.py
uv run pytest -q
uv run python scripts/live.py images
uv run python scripts/live.py deploy
```

Snapshots are built atomically into ignored `.build/trusted-index.json`, pinned
inside the search image and labeled with their indexing date. After seven days
they stop matching and requests fall back to whole-web search. Refresh is manual
in this first version; there is no invisible scheduler or promise of live indexed
content. Failed indexing preserves the previous snapshot and fails the command.
Add individual documentation pages when you need more coverage. Fifty pages and
one MiB per download are the current bounds; use a larger index service before
expanding to full domains. Rebuild the public source archive after code changes.

## Run locally

```sh
uv run python scripts/index_sources.py
docker build --platform linux/arm64 --target search -t gobwen-search .
docker run --rm --read-only --tmpfs /tmp:rw,size=128m --memory=512m \
  -p 127.0.0.1:8097:8080 gobwen-search
```

POST `/lookup` with `{"query":"Who is the Dutch king?"}`. Private diagnostic
`mode` may be `auto`, `indexed` or `web`; the public chat cannot override it.
`/healthz` confirms HTTP readiness. Live probes must test both routes and the
current AWS network: localhost success cannot establish upstream availability.

## Source and license

SearXNG is licensed under AGPL-3.0-or-later. The pinned official ARM64 image is
`sha256:d9ca82c19f98a684db92af79f5647028e39aaaa90d10611633260139f65b0c19`,
from upstream revision `12f8b6515ca77c3c3bc1498584950ef5daca1433` (2026-09-25).
The facade and index code in this directory are also provided under
AGPL-3.0-or-later; see `LICENSE-AGPL-3.0.txt`.

The website offers a source archive containing this adapter, build configuration,
indexer and the complete pinned upstream source. Indexed third-party documents
are data, not bundled source, and retain their respective owners' rights.
Upstream: https://github.com/searxng/searxng/tree/12f8b6515ca77c3c3bc1498584950ef5daca1433
