# Search service source

See search/README.md and search/LICENSE-AGPL-3.0.txt. The complete pinned SearXNG source is in upstream/.

Rebuild the service with `uv sync --frozen`, `uv run python scripts/index_sources.py`, then `docker build --platform linux/arm64 --target search -t gobwen-search .`. Only the search target is included; the unrelated model targets in the Dockerfile are not needed. Downloaded website content and private credentials are intentionally absent. The Docker target uses the official upstream image corresponding to the enclosed upstream source.
