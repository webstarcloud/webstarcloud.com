"""Private, bounded search facade. IAM is the external access boundary."""

import json
import logging
import os
import re
import secrets
import time
from pathlib import Path

# SearXNG can include a query in upstream failure logs. Suppress third-party logs;
# the facade writes only explicitly selected outcome/count/timing fields.
logging.disable(logging.CRITICAL)
os.environ.setdefault("SEARXNG_SECRET", secrets.token_hex(32))
from flask import Flask, jsonify, request
from index import retrieve, web_results
from searx.webapp import app as searx_app

INDEX = json.loads(Path("/app/trusted-index.json").read_text())
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 4096


@app.get("/healthz")
def health():
    return {"ready": True}


@app.post("/lookup")
def lookup():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or set(body) - {"query", "mode"}:
        return jsonify(error="invalid_request"), 400
    query, mode = body.get("query"), body.get("mode", "auto")
    if (
        not isinstance(query, str)
        or not 1 <= len(query.strip()) <= 300
        or not isinstance(mode, str)
        or mode not in {"auto", "indexed", "web"}
    ):
        return jsonify(error="invalid_request"), 400
    # Disable SearXNG bang/category syntax: the client cannot select extra engines
    # or send the query directly to an arbitrary destination.
    query = re.sub(r"[!:#]", " ", query).strip()
    started = time.monotonic()
    sources = retrieve(query, INDEX) if mode != "web" else []
    route, failures = "indexed", []
    if not sources and mode != "indexed":
        route = "web"
        try:
            with searx_app.test_client() as client:
                response = client.get(
                    "/search",
                    query_string={
                        "q": query,
                        "format": "json",
                        "categories": "general",
                        "language": "en",
                        "safesearch": 1,
                    },
                )
                if response.status_code != 200:
                    raise ValueError("Search unavailable")
                payload = response.get_json()
            failures = [
                str(item[0]) for item in payload.get("unresponsive_engines", [])
            ][:3]
            sources = web_results(query, payload.get("results", []))
        except Exception as error:  # noqa: BLE001 - upstream failures must not expose queries
            print(
                json.dumps(
                    {"event": "web_search_failed", "type": type(error).__name__}
                ),
                flush=True,
            )
            sources = []
    print(
        json.dumps(
            {
                "event": "lookup_complete",
                "route": route,
                "results": len(sources),
                "unavailable_engines": failures,
                "duration_ms": round((time.monotonic() - started) * 1000),
            }
        ),
        flush=True,
    )
    return jsonify(sources=sources, route=route, unavailableEngines=failures)
