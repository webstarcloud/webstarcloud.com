"""Small, immutable trusted-page index. No network or model is used for retrieval."""

import math
import re
from collections import Counter
from datetime import UTC, datetime

STOP = {
    "a",
    "an",
    "the",
    "to",
    "of",
    "is",
    "are",
    "was",
    "were",
    "who",
    "what",
    "when",
    "where",
    "how",
    "do",
    "does",
    "can",
    "i",
    "you",
    "it",
    "its",
    "on",
    "in",
    "at",
    "for",
    "and",
    "or",
    "with",
    "from",
    "my",
    "please",
    "tell",
    "me",
    "about",
    "explain",
    "search",
    "look",
    "up",
    "current",
    "latest",
    "today",
    "official",
    "release",
    "date",
}


def terms(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]{2,}", text.lower()) if t not in STOP}


def retrieve(query: str, index: dict, now: datetime | None = None) -> list[dict]:
    now = now or datetime.now(UTC)
    created = datetime.fromisoformat(index["indexed_at"])
    if not 0 <= (now - created).total_seconds() <= index["max_age_days"] * 86400:
        return []  # Stale snapshots must not silently answer current questions.
    wanted = terms(query)
    if not wanted:
        return []
    documents = index["documents"]
    tokens = [
        terms(doc["title"] + " " + doc["text"] + " " + " ".join(doc["keywords"]))
        for doc in documents
    ]
    frequency = Counter(term for doc in tokens for term in doc)
    scored = []
    for doc, available in zip(documents, tokens, strict=True):
        matched = wanted & available
        if len(matched) < min(2, len(wanted)) or len(matched) / len(wanted) < 0.5:
            continue
        # Rare query terms matter more than generic words shared by many pages.
        score = sum(math.log(1 + len(documents) / frequency[t]) for t in matched)
        passages = doc["passages"]
        best = max(
            passages, key=lambda p: sum(2 if t in terms(p) else 0 for t in wanted)
        )
        if not wanted & terms(best):
            continue
        scored.append(
            (
                score,
                {
                    "title": doc["title"],
                    "url": doc["url"],
                    "excerpt": best[:500],
                    "kind": "indexed",
                    "indexedAt": index["indexed_at"],
                },
            )
        )
    scored.sort(key=lambda item: item[0], reverse=True)
    return [source for _, source in scored[:3]]
